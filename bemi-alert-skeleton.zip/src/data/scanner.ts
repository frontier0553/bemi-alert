import {fetchTickers} from './binance'
import {evaluatePumpDump} from '../domain/rules'
import {prisma} from '../lib/prisma'

export async function runScanOnce(){
 const tickers=await fetchTickers()
 const top=tickers.slice(0,200)

 for(const t of top){
 const change=parseFloat(t.priceChangePercent)
 const volume=parseFloat(t.quoteVolume)

 const volMult=1
 const result=evaluatePumpDump(change,volMult,5,5,2)

 if(result){
 await prisma.event.create({
 data:{
 symbol:t.symbol,
 type:result,
 changePct:change,
 volumeMult:volMult,
 price:parseFloat(t.lastPrice)
 }
 })
 }
 }
}