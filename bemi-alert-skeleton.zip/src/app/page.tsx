export default function Home(){
 return(
 <main style={{padding:40,fontFamily:'system-ui'}}>
 <h1>Bemi Alert</h1>
 <p>Pump/Dump detection dashboard skeleton</p>
 <p>API: /api/events</p>
 </main>
 )
}